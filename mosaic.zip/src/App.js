import './App.css';
import React, {useState, useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Avatar from '@material-ui/core/Avatar';
import Divider from '@material-ui/core/Divider';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemAvatar from '@material-ui/core/ListItemAvatar';
import TextField from '@material-ui/core/TextField';
import AddIcon from '@material-ui/icons/Add';
import Collapse from '@material-ui/core/Collapse';
import ExpandLess from '@material-ui/icons/ExpandLess';
import ExpandMore from '@material-ui/icons/ExpandMore';

function App() {

  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchRes, setSearchRes] = useState([]);
  const [open, setOpen] = React.useState(false);


  

  useEffect(() => {
     fetch("https://api.hatchways.io/assessment/students")
    .then(res => res.json())
    .then(data => {
      // setData(data);
      const display = [];
      for(let i in data.students){
        const avg = data.students[i].grades.reduce((prev,cur) => (Number(prev) + Number(cur))) / data.students[i].grades.length;
        display.push({"id": data.students[i].id,"pic": data.students[i].pic, "name": data.students[i].firstName + " " + data.students[i].lastName, "email":"Email: " + data.students[i].email, "company": "Company: " + data.students[i].company, "skill": "Skill: " + data.students[i].skill,"avg": "Average: " + avg.toString()+"%", "grades": data.students[i].grades});
      }
      setSearchRes(display);
      //for whatever reason display becomes an empty array after this function is called so it is now being set as the hook data
      setData(display);
    });
  }, []);  

  console.log(data);

  const useStyles = makeStyles((theme) => ({
    root: {
      width: '35%',
      backgroundColor: theme.palette.background.paper,
      display: 'inline-block',
      '& > *': {
      margin: '5px 0',
      },
    },
    text: {
      color: 'black',
    },
    large: {
      width: theme.spacing(12),
      height: theme.spacing(12),
    },
    nested: {
      paddingLeft: '-30px',
      display: 'inline-block',
      width: '25%',
    },
  }));

  const classes = useStyles();

  const handleChange = e => {
    console.log("handleChange");
    setSearchTerm(e.target.value);
  };

  useEffect(() => {
    setSearchRes(data)
    console.log("search term change")
    const res = data.filter(o => o.name.toLowerCase().includes(searchTerm));
    
    setSearchRes(res);
  }, [searchTerm]);

  const handleClick = () => {
    setOpen(!open);
  };


  return (
    <div className="App">
      <header className="App-header">
          <List component="div" className={classes.root} style={{maxHeight: '100vh', overflow: 'auto', marginTop: '5em', marginBottom: '15em'}}>
            
                <TextField component="div" id="standard-search" label="Search" onChange={handleChange} value={searchTerm} style={{marginLeft:'0.2em', width: '100%'}}/>
                  {searchRes.map( a =>
                  <>
                  <ListItem component="div" button onClick={handleClick} >
                  <ListItemAvatar>
                    <Avatar src={a.pic} className={classes.large} style={{border: '0.5px solid grey'}}/>
                  </ListItemAvatar>
                  <ListItemText className={classes.text} 
                    primary={<h1>{a.name}</h1>} 
                    secondary={
                    <div>
                      <div>{a.email}</div>
                      <div>{a.company}</div>
                      <div>{a.skill}</div>
                      <div>{a.avg}</div>
                    </div>}
                    style={{marginLeft: '1em'}}>
                  </ListItemText>
                  {open ? <ExpandLess /> : <ExpandMore />}
                  </ListItem>
                  <Collapse in={open} timeout="auto" unmountOnExit>
                    <List component="div" disablePadding>
                      <ListItem button className={classes.nested} style={{marginLeft:'-15em'}}>
                        {a.grades.map( (val,i) => 
                          <>
                            <ListItemText secondary={
                            <ul>
                              <li key={i}>Test {i}: {val}%</li> 
                            </ul>
                             }/>
                          </>
                        )}
                      </ListItem>
                    </List>
                  </Collapse>
                  <Divider/>
                </>
                )}
            
          </List>
      </header>
    </div>
  );
}

export default App;
